package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "GenerateBillServlet", urlPatterns = {"/GenerateBillServlet"})
public class GenerateBillServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession sessionCart = request.getSession(true);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Generating Bill For The Book Shopping</title>");            
            out.println("</head>");
            out.println("<body bgcolor='pink'>");
            out.println("<h1 align='center'>Bill</h1>");
            out.println("<h2 align='center'>www.sharanamshah.com</h2>");
            out.println("<h5 align='right'><b>Date:</b> " + (new Date())+ "</h5><hr><br>");
            out.println("<table border='0' align='center' bordercolor='maroon' width='90%'>");
            out.println("<tr>");
            out.println("<td align='center' bgcolor='white' style='border: 2px dashed blue'><font color='blue'><b>Book</b></font></td>");
            out.println("<td align='center' bgcolor='white' style='border: 2px dashed blue'><font color='blue'><b>Price</b></font></td>");
            out.println("</tr>");

            String productName = null;
            float totalCost = 0;
            float price = 0;
            Enumeration productNames = sessionCart.getAttributeNames();
            for (int i=0; productNames.hasMoreElements(); i++) {
                productName = (String)productNames.nextElement();
                price = Float.valueOf((String)sessionCart. getAttribute(productName));
                out.println("<tr>");
                out.println("<td align='left' style='border:1px dashed #990033'>");
                out.println(productName);
                out.println("</td>");
                out.println("<td align='center' style='border:1px dashed #990033'>");
                out.println(price);
                out.println("</td>");
                out.println("</tr>");
                totalCost += price;
            }

            out.println("<tr>");
            out.println("<td align='right' style='border:3px dashed #990033'><b>Total: </b></td>");
            out.println("<td align='center' style='border:3px dashed #990033'>" + totalCost + "</td>");
            out.println("</tr>");
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
